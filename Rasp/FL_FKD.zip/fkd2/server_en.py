import socket
import struct
import zlib
import tempfile
import tensorflow as tf
import numpy as np
from tqdm import tqdm
from sklearn.metrics import classification_report
from tensorflow.keras.saving import register_keras_serializable
from tensorflow.keras import layers, initializers, backend as K
from sklearn.metrics import accuracy_score, f1_score, recall_score, classification_report, confusion_matrix
from cryptography.fernet import Fernet
import base64
import hashlib
import time
# Generate a shared secret key for encryption (must be the same on server and client)
# KEY = Fernet.generate_key()
# print("Generated Key:", KEY)
# cipher_suite = Fernet(KEY)




# Your custom key (e.g., a name or phrase)
custom_key = "secretkey"
# Hash the custom key using SHA-256 to get a 32-byte value
hashed_key = hashlib.sha256(custom_key.encode()).digest()
# Encode the hashed key as a URL-safe base64 string
encoded_key = base64.urlsafe_b64encode(hashed_key)
# Use the encoded key
KEY = encoded_key
cipher_suite = Fernet(KEY)
time_list =[]


# Custom Capsule Network Components
@register_keras_serializable(package="Custom")
class Length(layers.Layer):
    def call(self, inputs, **kwargs):
        return K.sqrt(K.sum(K.square(inputs), -1) + K.epsilon())
    
    def compute_output_shape(self, input_shape):
        return input_shape[:-1]
    
    def get_config(self):
        return super(Length, self).get_config()

@tf.keras.saving.register_keras_serializable(package="Custom")
class CapsuleLayer(layers.Layer):
    def __init__(self, num_capsule, dim_capsule, routings=3, **kwargs):
        super().__init__(**kwargs)
        self.num_capsule = num_capsule
        self.dim_capsule = dim_capsule
        self.routings = routings

    def build(self, input_shape):
        self.input_num_capsule = input_shape[1]
        self.input_dim_capsule = input_shape[2]
        
        self.W = self.add_weight(
            shape=[1, self.input_num_capsule, self.num_capsule, self.dim_capsule, self.input_dim_capsule],
            initializer=initializers.glorot_uniform(),
            name='W'
        )
        self.built = True

    def call(self, inputs):
        inputs_expand = K.expand_dims(K.expand_dims(inputs, 2), 2)
        W_tiled = K.tile(self.W, [K.shape(inputs)[0], 1, 1, 1, 1])
        inputs_hat = tf.squeeze(tf.matmul(W_tiled, inputs_expand, transpose_b=True), axis=-1)
        b = tf.zeros(shape=[K.shape(inputs)[0], self.input_num_capsule, self.num_capsule])

        for i in range(self.routings):
            c = tf.nn.softmax(b, axis=2)
            c_expand = K.expand_dims(c, -1)
            outputs = self.squash(tf.reduce_sum(inputs_hat * c_expand, axis=1))
            if i < self.routings - 1:
                b += tf.reduce_sum(inputs_hat * K.expand_dims(c, -1), axis=-1)
        
        return outputs
    def get_config(self):
        config = super().get_config()
        config.update({
            "num_capsule": self.num_capsule,
            "dim_capsule": self.dim_capsule,
            "routings": self.routings
        })
        return config
    def squash(self, vectors, axis=-1):
        s_squared_norm = K.sum(K.square(vectors), axis, keepdims=True)
        scale = s_squared_norm / (1 + s_squared_norm) / K.sqrt(s_squared_norm + K.epsilon())
        return scale * vectors

@tf.keras.saving.register_keras_serializable(package="Custom", name="margin_loss")
def margin_loss(y_true, y_pred):
    """
    Capsule Network Margin Loss with Shape Compatibility Fix
    - Expects y_true in categorical format (one-hot encoded)
    - Processes batch dimensions correctly
    - Maintains capsule network properties
    """
    # Convert labels to float32 if needed
    y_true = tf.cast(y_true, y_pred.dtype)
    
    # Ensure matching ranks by expanding dimensions if needed
    if len(y_true.shape) == len(y_pred.shape) - 1:
        y_true = tf.expand_dims(y_true, -1)
    
    # Calculate margin components
    positive_loss = y_true * tf.square(tf.maximum(0.9 - y_pred, 0.))
    negative_loss = 0.5 * (1 - y_true) * tf.square(tf.maximum(y_pred - 0.1, 0.))
    
    # Sum over capsules and average over batch
    return tf.reduce_mean(tf.reduce_sum(positive_loss + negative_loss, axis=-1))




class MobileNetCapsNet:
    def __init__(self, input_shape=(224, 224, 3)):
        self.input_shape = input_shape
        self.model = self._build_model()
    
    def _build_model(self):
        base_model = tf.keras.applications.MobileNetV2(
            input_shape=self.input_shape,
            include_top=False,
            weights='imagenet'
        )
        base_model.trainable = False
        
        x = base_model.output
        x = layers.Conv2D(256, 3, activation='relu')(x)
        x = layers.GlobalAveragePooling2D()(x)
        x = layers.Reshape((-1, 256))(x)
        
        x = CapsuleLayer(num_capsule=8, dim_capsule=16, routings=3)(x)
        x = CapsuleLayer(num_capsule=2, dim_capsule=32, routings=3)(x)
        outputs = Length()(x)
        outputs = tf.keras.layers.Reshape((2,))(outputs)
        
        return tf.keras.Model(inputs=base_model.input, outputs=outputs)
    
    def compile_model(self, learning_rate=0.001):
        """Compile the model with appropriate loss and optimizer"""
        optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
        
        self.model.compile(
            optimizer=optimizer,
            loss=self.margin_loss,
            metrics=['accuracy']
        )
        
    @staticmethod
    def margin_loss(y_true, y_pred):
        # Dynamic shape handling for unknown ranks
        rank = tf.rank(y_pred)
        y_pred = tf.cond(
            tf.equal(rank, 1),
            lambda: tf.expand_dims(y_pred, -1),
            lambda: y_pred
        )
        
        # Convert labels to one-hot encoding
        y_true = tf.one_hot(tf.cast(tf.squeeze(y_true), tf.int32), depth=2)
        
        # Margin loss calculation
        L = y_true * tf.square(tf.maximum(0., 0.9 - y_pred)) + \
            0.5 * (1 - y_true) * tf.square(tf.maximum(0., y_pred - 0.1))
        
        return tf.reduce_mean(tf.reduce_sum(L, axis=1))


class ServerDistiller(tf.keras.Model):
    def __init__(self, teacher, student):
        super().__init__()
        self.teacher = teacher
        self.student = student
        # Initialize metrics properly
        self.acc_metric = tf.keras.metrics.CategoricalAccuracy(name="accuracy")
        
    def compile(self, optimizer, temperature=3.0, alpha=0.1):
        # Remove explicit metrics passing
        super().compile(optimizer=optimizer)
        self.temperature = temperature
        self.alpha = alpha
        self.kl_loss = tf.keras.losses.KLDivergence()
        self.loss_tracker = tf.keras.metrics.Mean(name="loss")

    def train_step(self, data):
        x, y = data
        teacher_pred = self.teacher(x, training=False)
        
        with tf.GradientTape() as tape:
            student_pred = self.student(x, training=True)
            student_pred = tf.reshape(student_pred, [-1, 2])
            teacher_pred = tf.reshape(teacher_pred, [-1, 2])
            
            # Calculate losses
            student_loss = margin_loss(y, student_pred)
            distillation_loss = self.kl_loss(
                tf.nn.softmax(teacher_pred/self.temperature, axis=1),
                tf.nn.softmax(student_pred/self.temperature, axis=1)
            )
            total_loss = self.alpha * student_loss + (1 - self.alpha) * distillation_loss

        # Update accuracy metric
        y_labels = tf.argmax(y, axis=1)
        pred_labels = tf.argmax(student_pred, axis=1)
        self.acc_metric.update_state(y_labels, pred_labels)
        
        gradients = tape.gradient(total_loss, self.student.trainable_weights)
        self.optimizer.apply_gradients(zip(gradients, self.student.trainable_weights))
        
        self.loss_tracker.update_state(total_loss)
        return {
            "loss": self.loss_tracker.result(),
            "student_loss": student_loss,
            "distillation_loss": distillation_loss,
            "accuracy": self.acc_metric.result()
        }


# Load pre-trained global model
def load_model_from_file():
    return tf.keras.models.load_model("D:/Major Project/Rasp/Data/drowsiness_model.keras",
                                      custom_objects={'CapsuleLayer': CapsuleLayer,
                                                      'Length': Length,
                                                      'margin_loss': margin_loss})

def aggregate_weights(client_weights, beta=0.2):
    """Implements Federated Trimmed Averaging (FedTrimmedAvg) aggregation"""
    if not client_weights:
        return []
    
    num_clients = len(client_weights)
    k = int(beta * num_clients)
    k = max(0, min(k, (num_clients - 1) // 2))  # Ensure valid trim size
    
    aggregated_weights = []
    
    # Process each layer independently
    for layer_idx in range(len(client_weights[0])):
        # Stack all clients' layer weights into array
        layer_stack = np.array([client[layer_idx] for client in client_weights])
        original_shape = layer_stack.shape[1:]
        
        # Flatten for parameter-wise processing
        flattened = layer_stack.reshape(num_clients, -1)
        
        # Sort and trim parameters
        sorted_flat = np.sort(flattened, axis=0)
        trimmed = sorted_flat[k:num_clients-k] if k > 0 else sorted_flat
        
        # Compute mean of remaining values
        avg_flat = np.mean(trimmed, axis=0)
        
        # Restore original layer shape
        aggregated_weights.append(avg_flat.reshape(original_shape))
    
    return aggregated_weights


# Send the global model to the client
def send_global_model(client, global_model, round_num):
    with tempfile.NamedTemporaryFile(suffix=".keras", delete=False) as tmp:
        global_model.save(tmp.name)
        tmp.seek(0)
        model_data = tmp.read()

    compressed_data = zlib.compress(model_data)
    encrypted_data = cipher_suite.encrypt(compressed_data)  # Encrypt the data
    data_length = struct.pack('>I', len(encrypted_data))

    client.sendall(data_length)  # Send encrypted data size
    chunk_size = 1024 * 1024  # 1 MB per chunk
    with tqdm(total=len(encrypted_data), unit="B", unit_scale=True, desc="Sending model") as pbar:
        for i in range(0, len(encrypted_data), chunk_size):
            chunk = encrypted_data[i:i + chunk_size]
            client.sendall(chunk)
            pbar.update(len(chunk))
    print(f"Global model for Round {round_num} sent to client.")
    client.sendall(struct.pack('>I', round_num))  # Send round number

# Receive weights from the client
def receive_client_weights(client):
    data_length = struct.unpack('>I', client.recv(4))[0]  # Get size of the encrypted data
    received_data = b""
    while len(received_data) < data_length:
        packet = client.recv(1024 * 1024)
        if not packet:
            break
        received_data += packet

    decrypted_data = cipher_suite.decrypt(received_data)  # Decrypt the data
    decompressed_data = zlib.decompress(decrypted_data)
    with tempfile.NamedTemporaryFile(suffix=".keras", delete=False) as tmp:
        tmp.write(decompressed_data)
        tmp.flush()
        model = tf.keras.models.load_model(tmp.name, custom_objects={'CapsuleLayer': CapsuleLayer,
                                                      'Length': Length,
                                                      'margin_loss': margin_loss})
        return model.get_weights()

# Evaluate the global model
def evaluate_model(model, dataset_dir,start_time,end_time):
    datagen = tf.keras.preprocessing.image.ImageDataGenerator(rescale=1.0 / 255)
    test_gen = datagen.flow_from_directory(
                    dataset_dir,
                    target_size=(224, 224),
                    batch_size=32,
                    class_mode='categorical',
                    shuffle=False
                )
    predictions = np.argmax(model.predict(test_gen), axis=1)
    true_labels = test_gen.classes
    test_accuracy = accuracy_score(true_labels, predictions)
    confusion_mat = confusion_matrix(true_labels, predictions)
    f1 = f1_score(true_labels, predictions, average='weighted')
    recall = recall_score(true_labels, predictions, average='weighted')
    # Model size and number of parameters
    num_params = model.count_params()
    training_time = end_time - start_time
    time_list.append(training_time)
    print(f"Test Accuracy :    {test_accuracy:.2%}")
    print(f"F1 Score:          {f1:.4f}")
    print(f"Recall:            {recall:.4f}")
    print(f"Training Time:     {training_time:.2f} seconds")
    print(f"Number of Params:  {num_params:,}")
    print("\nConfusion Matrix:")
    print(confusion_mat)
    print("\nClassification Report after updating global model:")
    print(classification_report(true_labels, predictions, target_names=list(test_gen.class_indices.keys())))

def get_server_validation_data(train_dir):
    train_datagen = tf.keras.preprocessing.image.ImageDataGenerator(
        rescale=1./255,
        validation_split=0.2
    )
    
    val_gen = train_datagen.flow_from_directory(
        train_dir,
        target_size=(224, 224),
        batch_size=32,
        class_mode='categorical',
        subset='validation',
        shuffle=False
    )
    
    # Create dataset without loading all data into memory
    dataset = tf.data.Dataset.from_generator(
        lambda: val_gen,
        output_signature=(
            tf.TensorSpec(shape=(None, 224, 224, 3), dtype=tf.float32),
            tf.TensorSpec(shape=(None, 2), dtype=tf.float32)
        )
    )
    
    steps = val_gen.samples // val_gen.batch_size
    if val_gen.samples % val_gen.batch_size != 0:
        steps += 1
        
    return dataset, steps


        
# Server socket for federated learning
def server_socket():
    teacher_model = load_model_from_file()
    student_model = tf.keras.models.clone_model(teacher_model)
    student_model.set_weights(teacher_model.get_weights())   
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('0.0.0.0', 5000))  # Bind to all available IPs on port 5000
    server.listen(10)  # Listen for connections

    num_clients = 2  # Number of clients participating in federated learning
    client_sockets = []

    # Accept connections from all clients once
    print("Waiting for clients to connect...")
    for i in range(num_clients):
        client, addr = server.accept()
        print(f"Client {i + 1} connected from {addr}.")
        client_sockets.append(client)

    for round_num in range(1, 6):  # Perform 5 rounds
        print(f"\n==== Round {round_num} ====")
        client_weights = []

        # Step 1: Send the global model to all clients
        for client in client_sockets:
            send_global_model(client, student_model, round_num)

        # Collect client updates
        client_weights = [receive_client_weights(c) for c in client_sockets]
        
        # Server-side aggregation and distillation
        if round_num > 0:  # Start distillation after first round
            print("Performing server-side knowledge distillation...")
            distiller = ServerDistiller(teacher=teacher_model, student=student_model)
            distiller.compile(optimizer=tf.keras.optimizers.Adam(0.001),
                              temperature=3.0,
                              alpha=0.1) 
        # Use validation set for distillation (replace with your dataset)
            val_data,steps = get_server_validation_data("D:/Major Project/Rasp/Data/train")  
            student_model.summary()
            start_time = time.time()
            distiller.fit(val_data,steps_per_epoch=steps, epochs=2, verbose=1)
            end_time = time.time()

            # Update teacher model to current student
            teacher_model.set_weights(student_model.get_weights())
            
        # Apply FedTrimmedAvg even when not distilling    
        aggregated_weights = aggregate_weights(client_weights)
        student_model.set_weights(aggregated_weights)
        
        evaluate_model(student_model, "D:/Major Project/Rasp/Data/test",start_time,end_time)

    print(f"Training and weight update for all Rounds are completed.\n")
    time_avg = sum(time_list) / len(time_list)
    print(f"Average Time Taken for All Rounds{time_avg}.\n")

    # Step 5: Close all client connections after all rounds
    for client in client_sockets:
        client.close()
        print("Client connection closed.")

    server.close()
    print("Server shutdown.")

if __name__ == "__main__":
    server_socket()